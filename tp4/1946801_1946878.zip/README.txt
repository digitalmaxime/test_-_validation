executez la commande suivante pour s'assurer de couvrir les bonnes methodes

mut.py --target crud.py --unit-test test_crud_madum.py -m --coverage

mut.py --target crud.py --unit-test test_crud_conditions_T.py -m --coverage

mut.py --target crud.py --unit-test test_crud_conditions_F.py -m --coverage
